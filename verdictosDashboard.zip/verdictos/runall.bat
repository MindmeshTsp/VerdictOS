@echo off
title Agentic ProcessMaestro Automator
cls

echo ===================================================
echo [1/3] Launching Node.js API Server...
echo ===================================================
:: Starts your API server in the background exactly as before
start "ProcessMaestro Server" cmd /k "node server.js"

timeout /t 2 /nobreak > nul

echo ===================================================
echo [2/3] Launching Ngrok Tunnel on Port 3000...
echo ===================================================
:: Spins up ngrok to listen for data from your agents
start "Ngrok Tunnel Engine" cmd /k "ngrok http 3000 --url=phoney-quicksand-frisk.ngrok-free.dev"

timeout /t 3 /nobreak > nul

echo ===================================================
echo [3/3] Opening Your Local Webpage File...
echo ===================================================
:: Opens your index.html file locally using your browser
start "" "index.html"

echo.
echo Setup Complete! 
echo Your local interface is open, and ngrok is active on port 3000.
echo ===================================================
exit
