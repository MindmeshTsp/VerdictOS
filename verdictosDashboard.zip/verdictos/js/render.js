/* ============================================================
   VerdictOS — Rendering Engine
   Builds all DOM sections from data.js
   ============================================================ */

const Render = (() => {

  /* ─── helpers ─── */
  const el = (tag, cls, html) => {
    const e = document.createElement(tag);
    if (cls)  e.className = cls;
    if (html) e.innerHTML = html;
    return e;
  };

  /* ─── Loading screen ─── */
  function loadingScreen() {
    const steps = ['Initializing agents…','Loading evidence…','Connecting tribunal…','Ready.'];
    const bar   = document.querySelector('.load-bar');
    const txt   = document.querySelector('.load-text');
    let pct = 0, si = 0;
    const iv = setInterval(() => {
      pct += 2 + Math.random() * 5;
      if (pct >= 100) { pct = 100; clearInterval(iv); }
      if (bar) bar.style.width = pct + '%';
      const idx = Math.min(Math.floor(pct / 33), steps.length - 1);
      if (si !== idx) { si = idx; txt.textContent = steps[idx]; }
      if (pct >= 100) {
        setTimeout(() => {
          if (document.getElementById('loading-screen')) {
            document.getElementById('loading-screen').classList.add('hidden');
            setTimeout(() => document.getElementById('loading-screen').remove(), 600);
          }
        }, 300);
      }
    }, 40);
  }

  /* ─── Clock ─── */
  function clock() {
    const update = () => {
      const n = new Date();
      let h = n.getHours(), m = n.getMinutes(), s = n.getSeconds();
      const ap = h >= 12 ? 'PM' : 'AM';
      h = h % 12 || 12;
      const clk = document.getElementById('live-clock');
      if (clk) {
        clk.textContent =
          String(h).padStart(2,'0') + ':' + String(m).padStart(2,'0') + ':' +
          String(s).padStart(2,'0') + ' ' + ap;
      }
    };
    update(); setInterval(update, 1000);
  }

  /* ─── Sparkline SVG ─── */
  function sparkline(container, agent) {
    const pts = agent.sparkPoints;
    const W = 130, H = 36;
    const min = 0, max = 100;
    const xStep = W / (pts.length - 1);
    const mapped = pts.map((v, i) => ({
      x: i * xStep,
      y: H - ((v - min) / (max - min)) * (H - 4) - 2
    }));
    const d = mapped.map((p, i) => `${i===0?'M':'L'}${p.x.toFixed(1)},${p.y.toFixed(1)}`).join(' ');
    const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    svg.setAttribute('viewBox', `0 0 ${W} ${H}`);
    svg.setAttribute('preserveAspectRatio', 'none');
    svg.classList.add('agent-sparkline');
    const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
    path.setAttribute('d', d);
    path.setAttribute('fill', 'none');
    path.setAttribute('stroke', agent.color);
    path.setAttribute('stroke-width', '1.8');
    path.setAttribute('stroke-linecap', 'round');
    path.setAttribute('stroke-linejoin', 'round');
    svg.appendChild(path);
    container.appendChild(svg);
  }

  /* ─── Agent Cards ─── */
  function agentCards() {
    const row = document.querySelector('.agents-row');
    if (!row) return;
    row.innerHTML = ""; 
    
    AGENTS.forEach((a, i) => {
      const card = el('div', 'agent-card');
      card.dataset.agent = a.id;
      card.style.animationDelay = (i * 0.08) + 's';

      // ⚡ EXTRACTS INNER SCORE AND PERMIT STANDARD INLINE HTML CONTEXT INTERPRETATION
      const displayedScore = a.score;

      card.innerHTML = `
        <div class="agent-card-header">
          <div class="agent-icon ${a.id}">${a.icon}</div>
          <div class="agent-name">${a.name}</div>
        </div>
        <div class="agent-score-row">
          <span class="agent-score ${a.id}" data-target="${typeof a.score === 'number' ? a.score : 0}">${displayedScore}</span>
          <span class="score-denom">/100</span>
        </div>
        <div class="risk-badge ${a.riskClass}">${a.risk}</div>
      `;
      const status = el('div', 'agent-status', a.status);
      card.appendChild(status);
      sparkline(card, a);
      card.appendChild(status);

      const sp = card.querySelector('.agent-sparkline');
      card.insertBefore(sp, status);

      row.appendChild(card);
    });
  }

  /* ─── Deliberation Network SVG ─── */
  function network() {
    const svg = document.getElementById('network-svg');
    if (!svg) return;
    svg.innerHTML = ""; 
    
    const NS  = 'http://www.w3.org/2000/svg';
    const create = tag => document.createElementNS(NS, tag);

    const defs = create('defs');
    defs.innerHTML = `
      <filter id="glow-finance"><feGaussianBlur stdDeviation="3" result="blur"/>
        <feMerge><feMergeNode in="blur"/><feMergeNode in="SourceGraphic"/></feMerge></filter>
      <filter id="glow-legal"><feGaussianBlur stdDeviation="3" result="blur"/>
        <feMerge><feMergeNode in="blur"/><feMergeNode in="SourceGraphic"/></feMerge></filter>
    `;
    svg.appendChild(defs);

    CONNECTIONS.forEach(c => {
      const s = NODE_POS[c.from], e = NODE_POS[c.to];
      if (!s || !e) return;
      const line = create('line');
      line.setAttribute('x1', s.cx); line.setAttribute('y1', s.cy);
      line.setAttribute('x2', e.cx); line.setAttribute('y2', e.cy);
      const styles = {
        strong:   { stroke:'#16a34a', sw:'2.2', dash:'' },
        neutral:  { stroke:'#94a3b8', sw:'1.5', dash:'4,3' },
        question: { stroke:'#ea6c00', sw:'1.8', dash:'6,4' },
        disagree: { stroke:'#dc2626', sw:'1.8', dash:'' },
      };
      const st = styles[c.type] || styles.neutral;
      line.setAttribute('stroke', st.stroke);
      line.setAttribute('stroke-width', st.sw);
      if (st.dash) line.setAttribute('stroke-dasharray', st.dash);
      svg.appendChild(line);
    });

    // ⚡ SAFE FILTER: Renders standard static string text within the SVG matrix during running cycles
    const getScoreStr = (id) => {
      if (id === 'judge') return (typeof JUDGE.score === 'number') ? Math.round(JUDGE.score) + '%' : '....';
      const match = AGENTS.find(a => a.id === id);
      return match ? ((typeof match.score === 'number') ? Math.round(match.score) + '%' : '....') : '0%';
    };

    // 🛠️ ALIGNED GEOMETRY MODEL RADII PROPORTIONS
    const nodeData = {
      legal:      { label:'LEGAL AGENT',    pct:getScoreStr('legal'), icon:'⚖️', r:40, stroke:'#7c3aed', bgFill:'#f5f3ff', textColor:'#7c3aed', scoreColor:'#1e293b' },
      finance:    { label:'FINANCE AGENT',  pct:getScoreStr('finance'), icon:'💲', r:44, stroke:'#2563eb', bgFill:'#eff6ff', textColor:'#2563eb', scoreColor:'#1e293b', glow:'glow-finance' },
      judge:      { label:'JUDGE AGENT',    pct:getScoreStr('judge'), icon:'⚖',  r:44, stroke:'#94a3b8', bgFill:'#f8fafc', textColor:'#475569', scoreColor:'#1e293b' },
      cyber:      { label:'CYBER AGENT',    pct:getScoreStr('cyber'), icon:'🛡️', r:42, stroke:'#16a34a', bgFill:'#f0fdf4', textColor:'#16a34a', scoreColor:'#1e293b' },
      human:      { label:'HUMAN INTENT',   pct:getScoreStr('human'), icon:'👤', r:40, stroke:'#ea6c00', bgFill:'#fff7ed', textColor:'#ea6c00', scoreColor:'#1e293b', sub:'AGENT' },
      reputation: { label:'REPUTATION',     pct:getScoreStr('reputation'), icon:'🌐', r:40, stroke:'#dc2626', bgFill:'#fff1f2', textColor:'#dc2626', scoreColor:'#1e293b', sub:'AGENT' },
      precedent:  { label:'PRECEDENT',      pct:getScoreStr('precedent'), icon:'📚', r:40, stroke:'#475569', bgFill:'#f1f5f9', textColor:'#475569', scoreColor:'#1e293b', sub:'AGENT' }
    };

    Object.entries(nodeData).forEach(([id, nd]) => {
      const pos = NODE_POS[id];
      const g = create('g');
      g.setAttribute('class', 'net-node');
      g.setAttribute('data-node', id);

      const circ = create('circle');
      circ.setAttribute('cx', pos.cx); circ.setAttribute('cy', pos.cy);
      circ.setAttribute('r', nd.r);
      circ.setAttribute('fill', nd.bgFill);
      circ.setAttribute('stroke', nd.stroke);
      circ.setAttribute('stroke-width', '2.5');
      if (nd.glow) circ.setAttribute('filter', `url(#${nd.glow})`);
      g.appendChild(circ);

      const ico = create('text');
      ico.setAttribute('x', pos.cx); ico.setAttribute('y', pos.cy - nd.r * 0.28);
      ico.setAttribute('text-anchor', 'middle'); ico.setAttribute('dominant-baseline', 'middle');
      ico.setAttribute('font-size', '14');
      ico.setAttribute('font-family', 'sans-serif');
      ico.textContent = nd.icon;
      g.appendChild(ico);

      if (nd.sub) {
        const t1 = create('text');
        t1.setAttribute('x', pos.cx); t1.setAttribute('y', pos.cy + nd.r * 0.1);
        t1.setAttribute('text-anchor', 'middle'); t1.setAttribute('fill', nd.textColor);
        t1.setAttribute('font-size', '7.5'); t1.setAttribute('font-weight', '700');
        t1.setAttribute('font-family', 'Inter,sans-serif');
        t1.textContent = nd.label;
        g.appendChild(t1);
        const t2 = create('text');
        t2.setAttribute('x', pos.cx); t2.setAttribute('y', pos.cy + nd.r * 0.1 + 10);
        t2.setAttribute('text-anchor', 'middle'); t2.setAttribute('fill', nd.textColor);
        t2.setAttribute('font-size', '7.5'); t2.setAttribute('font-weight', '700');
        t2.setAttribute('font-family', 'Inter,sans-serif');
        t2.textContent = nd.sub;
        g.appendChild(t2);
        
        const sc = create('text');
        sc.setAttribute('id', 'node-sc-text-' + id); 
        sc.setAttribute('x', pos.cx); sc.setAttribute('y', pos.cy + nd.r * 0.6);
        sc.setAttribute('text-anchor', 'middle'); sc.setAttribute('fill', nd.scoreColor);
        sc.setAttribute('font-size', '11'); sc.setAttribute('font-weight', '800');
        sc.setAttribute('font-family', 'Inter,sans-serif');
        sc.textContent = nd.pct;
        g.appendChild(sc);
      } else {
        const lbl = create('text');
        lbl.setAttribute('x', pos.cx); lbl.setAttribute('y', pos.cy + nd.r * 0.15);
        lbl.setAttribute('text-anchor', 'middle'); lbl.setAttribute('fill', nd.textColor);
        lbl.setAttribute('font-size', '8'); lbl.setAttribute('font-weight', '700'); 
        lbl.setAttribute('font-family', 'Inter,sans-serif');
        lbl.textContent = nd.label;
        g.appendChild(lbl);
        
        const sc = create('text');
        sc.setAttribute('id', 'node-sc-text-' + id); 
        sc.setAttribute('x', pos.cx); sc.setAttribute('y', pos.cy + nd.r * 0.55);
        sc.setAttribute('text-anchor', 'middle'); sc.setAttribute('fill', nd.scoreColor);
        sc.setAttribute('font-size', '12'); sc.setAttribute('font-weight', '800'); 
        sc.setAttribute('font-family', 'Inter,sans-serif');
        sc.textContent = nd.pct;
        g.appendChild(sc);
      }

      g.addEventListener('mouseenter', () => {
        circ.setAttribute('stroke-width', '3.5');
        circ.style.filter = `drop-shadow(0 0 6px ${nd.stroke}66)`;
      });
      g.addEventListener('mouseleave', () => {
        if (!circ.classList.contains('net-node-active-pulse')) {
            circ.setAttribute('stroke-width', '2.5');
            circ.style.filter = '';
        } else {
            circ.style.filter = `drop-shadow(0 0 16px ${circ.style.getPropertyValue('--node-pulse-color') || '#2563eb'})`;
        }
      });

      svg.appendChild(g);
    });
  }

  /* ─── Risk Wave Chart (Canvas Layout with Interpolated Progressive Animations) ─── */
  function riskChart() {
    const canvas = document.getElementById('risk-chart');
    if (!canvas) return;
    const ctx    = canvas.getContext('2d');
    const tooltip = document.getElementById('chart-tooltip');

    const colors = { finance: '#2563eb', cyber: '#16a34a', legal: '#7c3aed', human: '#ea6c00', reputation: '#dc2626', precedent: '#475569' };
    const seriesKeys = ['finance','cyber','legal','human','reputation', 'precedent'];
    const seriesNames = { finance:'Finance',cyber:'Cyber',legal:'Legal',human:'Human Intent',reputation:'Reputation', precedent: 'Precedent' };
    
    let hoveredX = -1;
    let animationProgress = 0; 
    let animationId = null;

    function renderFrame() {
      if (!canvas.offsetWidth) return;
      const W = canvas.offsetWidth;
      const H = canvas.offsetHeight;
      canvas.width  = W * devicePixelRatio;
      canvas.height = H * devicePixelRatio;
      ctx.scale(devicePixelRatio, devicePixelRatio);
      ctx.clearRect(0, 0, W, H);

      if (typeof AGENTS[0].score === 'string') return; 

      const PAD_L = 36, PAD_R = 12, PAD_T = 8, PAD_B = 12;
      const chartW = W - PAD_L - PAD_R;
      const chartH = H - PAD_T - PAD_B;
      const N = WAVE_DATA.finance.length;
      const xStep = chartW / (N - 1);

      ctx.strokeStyle = '#e2e7f0'; ctx.lineWidth = 0.7;
      ctx.fillStyle   = '#94a3b8';
      ctx.font        = `9px Inter`;
      ctx.textAlign   = 'right';
      [0,25,50,75,100].forEach((v, i) => {
        const y = PAD_T + chartH - (v / 100) * chartH;
        ctx.beginPath(); ctx.moveTo(PAD_L, y); ctx.lineTo(W - PAD_R, y); ctx.stroke();
        ctx.fillText(v, PAD_L - 4, y + 3);
      });

      ctx.save();
      ctx.translate(9, H / 2);
      ctx.rotate(-Math.PI / 2);
      ctx.font = '8px Inter'; ctx.fillStyle = '#94a3b8'; ctx.textAlign = 'center';
      ctx.fillText('Risk Score (0–100)', 0, 0);
      ctx.restore();

      if (hoveredX >= 0) {
        ctx.strokeStyle = '#dde2ef'; ctx.lineWidth = 1;
        ctx.setLineDash([4, 3]);
        ctx.beginPath(); ctx.moveTo(hoveredX, PAD_T); ctx.lineTo(hoveredX, PAD_T + chartH); ctx.stroke();
        ctx.setLineDash([]);
      }

      seriesKeys.forEach(key => {
        if (!WAVE_DATA[key]) return;
        const pts = WAVE_DATA[key].map((v, i) => {
          const interpolatedValue = v * animationProgress;
          return {
            x: PAD_L + i * xStep,
            y: PAD_T + chartH - (interpolatedValue / 100) * chartH
          };
        });

        ctx.beginPath();
        ctx.moveTo(pts[0].x, PAD_T + chartH);
        pts.forEach((p, i) => {
          if (i === 0) ctx.lineTo(p.x, p.y);
          else {
            const cpx = (pts[i-1].x + p.x) / 2;
            ctx.bezierCurveTo(cpx, pts[i-1].y, cpx, p.y, p.x, p.y);
          }
        });
        ctx.lineTo(pts[pts.length-1].x, PAD_T + chartH);
        ctx.closePath();
        ctx.fillStyle = colors[key] + '12';
        ctx.fill();

        ctx.beginPath();
        ctx.moveTo(pts[0].x, pts[0].y);
        pts.forEach((p, i) => {
          if (i === 0) return;
          const cpx = (pts[i-1].x + p.x) / 2;
          ctx.bezierCurveTo(cpx, pts[i-1].y, cpx, p.y, p.x, p.y);
        });
        ctx.strokeStyle = colors[key]; ctx.lineWidth = 2; ctx.stroke();

        pts.forEach(p => {
          ctx.beginPath(); ctx.arc(p.x, p.y, 3.5, 0, Math.PI * 2);
          ctx.fillStyle = colors[key]; ctx.fill();
          ctx.strokeStyle = '#fff'; ctx.lineWidth = 1.5; ctx.stroke();
        });
      });
    }

    function startWaveAnimation() {
        if (animationId) cancelAnimationFrame(animationId);
        animationProgress = 0; 
        function runStep() {
            animationProgress += 0.025; 
            if (animationProgress > 1) animationProgress = 1;
            renderFrame();
            if (animationProgress < 1) {
                animationId = requestAnimationFrame(runStep);
            }
        }
        runStep();
    }

    canvas.addEventListener('mousemove', e => {
      if (typeof AGENTS[0].score === 'string' || animationProgress < 1) return;
      const rect  = canvas.getBoundingClientRect();
      const mx    = e.clientX - rect.left;
      const PAD_L = 36, PAD_R = 12;
      const chartW = canvas.offsetWidth - PAD_L - PAD_R;
      const N = WAVE_DATA.finance.length;
      const xStep = chartW / (N - 1);
      const idx = Math.round((mx - PAD_L) / xStep);

      if (idx >= 0 && idx < N && tooltip) {
        hoveredX = PAD_L + idx * xStep;
        renderFrame();
        const label = WAVE_DATA.labels[idx] ? WAVE_DATA.labels[idx].replace('\n', ' ') : '';
        let rows = `<div class="tt-title">${label}</div>`;
        seriesKeys.forEach(k => {
          if (!WAVE_DATA[k]) return;
          rows += `<div class="tt-row">
            <div class="tt-dot" style="background:${colors[k]}"></div>
            <span class="tt-label">${seriesNames[k]}</span>
            <span class="tt-val" style="color:${colors[k]}">${WAVE_DATA[k][idx]}</span>
          </div>`;
        });
        tooltip.innerHTML = rows;
        tooltip.classList.add('visible');
        tooltip.style.left = (e.clientX + 14) + 'px';
        tooltip.style.top  = (e.clientY - 20) + 'px';
      }
    });
    canvas.addEventListener('mouseleave', () => {
      hoveredX = -1; renderFrame();
      if (tooltip) tooltip.classList.remove('visible');
    });

    window.addEventListener('resize', () => { canvas.width = 0; setTimeout(renderFrame, 50); });
    startWaveAnimation();
  }

  /* ─── Voting Matrix ─── */
  function votingMatrix() {
    const grid = document.querySelector('.voting-grid');
    if (!grid) return;
    grid.innerHTML = ""; 
    
    AGENTS.forEach(a => {
      const col = el('div', 'vote-col');
      col.innerHTML = `
        <div class="vote-agent ${a.id}">${a.name}</div>
        <div class="vote-verdict ${a.voteClass}">${a.vote}</div>
        <div class="vote-conf">Confidence: ${a.confidence}%</div>
      `;
      grid.appendChild(col);
    });
  }

  /* ─── Consensus Donut ─── */
  function consensusDonut(customPct) {
    const pct = customPct !== undefined ? customPct : 0; 
    const r   = 36, cx = 45, cy = 45;
    const circ = 2 * Math.PI * r;
    const fill = (pct / 100) * circ;
    const svg  = document.getElementById('donut-svg');
    if (!svg) return;
    
    svg.innerHTML = `
      <circle cx="${cx}" cy="${cy}" r="${r}" fill="none" stroke="#e2e8f0" stroke-width="10"/>
      <circle cx="${cx}" cy="${cy}" r="${r}" fill="none"
        stroke="#16a34a" stroke-width="10"
        stroke-dasharray="${fill} ${circ}"
        stroke-dashoffset="${circ * 0.25}"
        stroke-linecap="round"
        transform="rotate(-90 ${cx} ${cy})"/>
    `;
  }

  /* ─── Public init ─── */
  function init() {
    loadingScreen();
    clock();
    agentCards();
    network();
    riskChart();
    votingMatrix();
    consensusDonut();
  }

  return { init, agentCards, network, votingMatrix, consensusDonut, riskChart };
})();