// ============================================================
//  VerdictOS — Application Data & State
// ============================================================

const AGENTS = [
  {
    id: 'finance',
    name: 'Finance Agent',
    icon: '💲',
    score: 0, 
    risk: 'Standby',
    riskClass: 'moderate',
    status: 'Awaiting financial impact vector matrix...',
    color: '#2563eb',
    bgLight: '#dbeafe',
    sparkPoints: [0, 15, 30, 45, 60, 75, 90, 100],
    vote: 'PENDING',
    voteClass: 'review',
    confidence: 0,
  },
  {
    id: 'cyber',
    name: 'Cyber Agent',
    icon: '🛡',
    score: 0,
    risk: 'Standby',
    riskClass: 'moderate',
    status: 'Awaiting network indicator vectors...',
    color: '#16a34a',
    bgLight: '#dcfce7',
    sparkPoints: [0, 20, 40, 55, 70, 80, 85, 90],
    vote: 'PENDING',
    voteClass: 'review',
    confidence: 0,
  },
  {
    id: 'legal',
    name: 'Legal Agent',
    icon: '⚖',
    score: 0,
    risk: 'Standby',
    riskClass: 'moderate',
    status: 'Awaiting corporate legal parameters...',
    color: '#7c3aed',
    bgLight: '#ede9fe',
    sparkPoints: [0, 10, 25, 45, 65, 75, 80, 85],
    vote: 'PENDING',
    voteClass: 'review',
    confidence: 0,
  },
  {
    id: 'human',
    name: 'Human Intent Agent',
    icon: '👤',
    score: 0,
    risk: 'Standby',
    riskClass: 'moderate',
    status: 'Awaiting interactive request telemetry...',
    color: '#ea6c00',
    bgLight: '#ffedd5',
    sparkPoints: [0, 15, 35, 50, 60, 70, 75, 80],
    vote: 'PENDING',
    voteClass: 'review',
    confidence: 0,
  },
  {
    id: 'reputation',
    name: 'Reputation Agent',
    icon: '🌐',
    score: 0,
    risk: 'Standby',
    riskClass: 'moderate',
    status: 'Awaiting external social sentiment channels...',
    color: '#dc2626',
    bgLight: '#fee2e2',
    sparkPoints: [0, 5, 20, 40, 55, 65, 70, 75],
    vote: 'PENDING',
    voteClass: 'review',
    confidence: 0,
  },
  {
    id: 'precedent',
    name: 'Precedent Agent',
    icon: '📚',
    score: 0,
    risk: 'Standby',
    riskClass: 'moderate',
    status: 'Awaiting case history matching records...',
    color: '#475569',
    bgLight: '#f1f5f9',
    sparkPoints: [0, 12, 28, 40, 58, 66, 74, 86],
    vote: 'PENDING',
    voteClass: 'review',
    confidence: 0,
  }
];

const JUDGE = { score: 0, color: '#475569', bgLight: '#f1f5f9' };

let FEED_ITEMS = [];
let TIMELINE_ITEMS = [];

const WAVE_DATA = {
  labels: [],
  finance:    [0, 0, 0, 0, 0, 0, 0, 0, 0],
  cyber:      [0, 0, 0, 0, 0, 0, 0, 0, 0],
  legal:      [0, 0, 0, 0, 0, 0, 0, 0, 0],
  human:      [0, 0, 0, 0, 0, 0, 0, 0, 0],
  reputation: [0, 0, 0, 0, 0, 0, 0, 0, 0],
  precedent:  [0, 0, 0, 0, 0, 0, 0, 0, 0]
};

// 🛠️ REMOVED ALL INTER-AGENT CONNECTIONS — EVERY NODE LINKS ONLY TO THE JUDGE
const CONNECTIONS = [
  { from: 'finance',    to: 'judge', type: 'strong' },
  { from: 'cyber',      to: 'judge', type: 'strong' },
  { from: 'legal',      to: 'judge', type: 'strong' },
  { from: 'human',      to: 'judge', type: 'strong' },
  { from: 'reputation', to: 'judge', type: 'strong' },
  { from: 'precedent',  to: 'judge', type: 'strong' }
];

// 520×330 ViewBox Geometric Mesh Layout Coordinates (Legal at Top Apex, Judge in center mesh row)
const NODE_POS = {
  legal:      { cx: 258, cy: 45  },
  finance:    { cx: 100, cy: 145 },
  judge:      { cx: 258, cy: 145 },
  cyber:      { cx: 415, cy: 145 },
  human:      { cx: 100, cy: 265 },
  reputation: { cx: 415, cy: 265 },
  precedent:  { cx: 258, cy: 265 }
};