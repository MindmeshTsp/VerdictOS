const http = require('http');

let requestLogs = [];

// Global tracking structure for our dynamic human intervention loop
let humanDecision = { status: "PENDING", choice: null };

const server = http.createServer((req, res) => {
    // Wide-open wildcard headers to bypass every security block
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', '*'); // Accepts ALL custom UiPath headers
    res.setHeader('Access-Control-Allow-Credentials', 'true');

    if (req.method === 'OPTIONS') {
        res.writeHead(200);
        return res.end();
    }

    // 1. DASHBOARD DATA FEED PIPELINE
    if (req.method === 'GET' && req.url === '/requests') {
        res.writeHead(200, { 'Content-Type': 'application/json' });
        return res.end(JSON.stringify({ data: requestLogs }));
    }

    // 2. UIPATH RESULTS POOL CHECKER (Long Polling Loop Targets This)
    if (req.method === 'GET' && req.url === '/get-decision') {
        res.writeHead(200, { 
            'Content-Type': 'application/json',
            'ngrok-skip-browser-warning': 'true' // In-code defense against ngrok intercept blockers
        });
        return res.end(JSON.stringify(humanDecision));
    }

    // 3. HUMAN OVERSIGHT BUTTON SUBMISSION DELEGATE
    if (req.method === 'POST' && req.url === '/submit-decision') {
        let body = '';
        req.on('data', chunk => { body += chunk.toString(); });
        req.on('end', () => {
            try {
                const parsedBody = JSON.parse(body);
                if (!parsedBody.choice) {
                    res.writeHead(400, { 'Content-Type': 'application/json' });
                    return res.end(JSON.stringify({ error: "Missing button choice element" }));
                }

                // Update runtime verdict tracking memory allocation structures
                humanDecision = {
                    status: "COMPLETED",
                    choice: parsedBody.choice.toUpperCase(), // "APPROVE", "REJECT", or "ESCALATE"
                    timestamp: new Date()
                };

                console.log(`👤 Human Decision Logged: [${humanDecision.choice}]`);
                res.writeHead(200, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ message: "Decision recorded", data: humanDecision }));
            } catch (e) {
                res.writeHead(400, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ error: "Invalid JSON format" }));
            }
        });
        return;
    }

    // 4. RESET VERDICT SYSTEM STATE (Trigger at the start of a fresh UiPath run)
    if (req.method === 'POST' && req.url === '/reset-decision') {
        humanDecision = { status: "PENDING", choice: null };
        requestLogs = []; // <-- CRITICAL FIX: Flush out old array data logs so layout loops stop!
        
        console.log("🔄 Courtroom flushed: State set to PENDING and request logs cleared.");
        res.writeHead(200, { 'Content-Type': 'application/json' });
        return res.end(JSON.stringify({ message: "Decision reset and data clear successful" }));
    }

    // 5. ORIGINAL UIPATH DATA POOL INTAKE
    if (req.method === 'POST' && req.url === '/webhook') {
        let body = '';
        req.on('data', chunk => { body += chunk.toString(); });
        req.on('end', () => {
            console.log("📥 Server just caught a payload from UiPath!");
            requestLogs.unshift({
                uuid: Math.random().toString(36).substring(2),
                content: body
            });
            if (requestLogs.length > 50) requestLogs.pop();
            
            res.writeHead(200, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ status: "success" }));
        });
    } else {
        // Fallback catch criteria for unauthorized root endpoints
        const validRoutes = ['/requests', '/webhook', '/submit-decision', '/get-decision', '/reset-decision'];
        if (!validRoutes.includes(req.url)) {
            res.writeHead(404, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ error: `Route ${req.url} not found on this system blueprint.` }));
        }
    }
});

server.listen(3000, '0.0.0.0', () => {
    console.log("🚀 Unlimited Courtroom server alive at http://localhost:3000");
});